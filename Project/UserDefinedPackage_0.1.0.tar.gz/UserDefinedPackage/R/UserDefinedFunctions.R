

#source("read_mydata.R")
library(glmnet)
library(arsenal)
library(mice)

raw_data <-function(){

  data_census<- read.table("https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data")
  names(data_census) <- c("age", "workclass", "fnlwgt", "education", "educationNum", "maritalStatus", "occupation", "relationship", "race", "sex", "capitalGain", "capitalLoss", "hoursPerweek", "nativeCountry", "income")
  data_census$hoursPerweek = gsub(",", "", data_census$hoursPerweek, fixed=TRUE)
  class(data_census$hoursPerweek) <- "numeric"
  data_census<- as.data.frame(data_census)
  return(data_census)
}
read_mydata<- function(){

  data_census<- read.table("https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data")
  names(data_census) <- c("age", "workclass", "fnlwgt", "education", "educationNum", "maritalStatus", "occupation", "relationship", "race", "sex", "capitalGain", "capitalLoss", "hoursPerweek", "nativeCountry", "income")

  data.y <- data_census[["income"]]
  data.x <-data_census[["hoursPerweek"]]

  my_list <- list("data.y" = data_census[["income"]], "data.x" = data_census[["hoursPerweek"]])

  my_list$data.y <- ifelse(my_list$data.y=="<=50K",1,0)

  my_list$data.x = gsub(",", "", my_list$data.x, fixed=TRUE)

  class(my_list$data.x) <- "numeric"

  my_list$data.y = gsub(" ", "", my_list$data.y, fixed=TRUE)

  class(my_list$data.y) <- "numeric"
  return(my_list)
}

includeNas <- function(data){

  data <- as.data.frame(data)
  randVal1 = round(runif(1,0,5))
  randVal2 = round(runif(1,5,20))
  randVal3 = round(runif(1,0,5))
  randVal4 = round(runif(1,5,20))
  data[randVal1:randVal2,1] <- rep(NA,randVal2-randVal1+1)
  data[randVal3:randVal4,2] <- rep(NA,randVal4-randVal3+1)
  data
}

F1_mle <- function(data){
  B0 <- data[1]
  B1 <- data[2]

  resData = read_mydata()
  #resData = iris
# resData$data.y <- ifelse(resData$data.y=="<=50K",1,0)
# resData$data.x = gsub(",", "", resData$data.x, fixed=TRUE)
# class(resData$data.x) <- "numeric"
# resData$data.y = gsub(" ", "", resData$data.y, fixed=TRUE)
# class(resData$data.y) <- "numeric"

  y <- resData$data.y
  x1 <- resData$data.x
  X <- B0 + B1 * x1
  p <- exp(X) / (1 + exp(X))
  F1_mle <- -sum(y * log(p) + (1 - y) * log(1 - p))
  F1_mle
}

OptimUserDefined <-function(){


MLE <- optim(c(0.1,0.1),
             fn = F1_mle,
             control = list(trace = 0),
             hessian = FALSE)
MLE
print(MLE$par)
}

InbuildGlmUserDefined <- function(data){
  y <- data$data.y
  x1 <- data$data.x
  glm_model <- glm(y ~ x1 ,
                   family = binomial(link = "logit"))

 print(glm_model)
 print(paste("Coefficients are: ",coef(glm_model)))
}

NewtonRaphsonDefine <- function (x1,y, itr, B0=2,B1=0) {

  b0 <- rep(0,itr+1)
  b1 <- rep(0,itr+1)
  b0[1] <- B0
  b1[1] <- B1

  for (i in 1:itr){

    e <- exp(b0[i] + b1[i] * x1)

    #b0[i+1] =b0[i]-((sum(y)-sum(e/(1+e))/-sum(e/e^2)))
    #b1[i+1]=b1[i]-((sum(x1*y)-sum(x1*e/(1+e)))/-sum(((x1^2)*e)/(e^2)))

    b0[i+1]=b0[i]-((sum(y)-sum(e/(1+e)))/(-sum((e)/(e+1)^2)))
    b1[i+1]=b1[i]-((sum(x1*y)-sum(x1*e/(1+e)))/(-sum(((x1^2)*e)/(e^2))))
  }

  data = c(b0,b1)
  finaldf = data.frame (b0=b0,b1=b1)
  finaldf

}


NewtonRaphsonUserDefined <- function(data){

  y <- data$data.y
  x1 <- data$data.x
  #print(F1(3,0.4))
  final <- NewtonRaphsonDefine(x1,y,150)
  final[151,]
}


ImputationFix <- function(data){
library(mice)
tempData <- mice(data,m=7,meth='mean') #pmm, norm.nob, rf, boot
summary(tempData)
return(complete(tempData))
}


