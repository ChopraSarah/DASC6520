read_mydata<- function(){

  data_census<- read.table("https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data")
  names(data_census) <- c("age", "workclass", "fnlwgt", "education", "educationNum", "maritalStatus", "occupation", "relationship", "race", "sex", "capitalGain", "capitalLoss", "hoursPerweek", "nativeCountry", "income")

  data.y <- data_census[["income"]]
  data.x <-data_census[["hoursPerweek"]]

  my_list <- list("data.y" = data_census[["income"]], "data.x" = data_census[["hoursPerweek"]])

  my_list$data.y <- ifelse(my_list$data.y=="<=50K",1,0)

  my_list$data.x = gsub(",", "", my_list$data.x, fixed=TRUE)

  class(my_list$data.x) <- "numeric"

  my_list$data.y = gsub(" ", "", my_list$data.y, fixed=TRUE)

  class(my_list$data.y) <- "numeric"
  return(my_list)
}
